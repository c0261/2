#!/bin/bash

echo "Stopping meshagent..."
sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagent.plist"
sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagentDiagnostic_periodicStart.plist" &> /dev/null
sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagentDiagnostic.plist" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagentDiagnostic_periodicStart.plist" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagentDiagnostic.plist" &> /dev/null
sudo rm "/usr/local/mesh_services/meshagent/meshagent/meshagent"
sudo rm "/usr/local/mesh_services/meshagent/meshagent/meshagent.msh"
sudo rm "/usr/local/mesh_services/meshagent/meshagent/meshagent.db"
sudo rm "/usr/local/mesh_services/meshagentDiagnostic/meshagentDiagnostic" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagent.plist"
sudo rm "/Library/LaunchAgents/meshagent.plist"
echo "meshagent was uninstalled."

