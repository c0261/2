#!/bin/bash

cp "$1/Contents/meshagent_osx64.msh" "/usr/local/mesh_services/meshagent/meshagent/meshagent.msh"
cp "$1/Contents/meshagent_osx64.bin" "/usr/local/mesh_services/meshagent/meshagent/meshagent"
cp "$1/Contents/meshagent_osx64_LaunchDaemon.plist" "/Library/LaunchDaemons/meshagent.plist"
cp "$1/Contents/meshagent_osx64_LaunchAgent.plist" "/Library/LaunchAgents/meshagent.plist"
rm "/usr/local/mesh_services/meshagent/meshagent/internal.txt"

chown root:wheel "/usr/local/mesh_services/meshagent/meshagent"
chown root:wheel "/usr/local/mesh_services/meshagent/meshagent/meshagent"
chown root:wheel "/Library/LaunchDaemons/meshagent.plist"
chown root:wheel "/Library/LaunchAgents/meshagent.plist"

chmod 755 "/usr/local/mesh_services/meshagent/meshagent"
chmod 755 "/usr/local/mesh_services/meshagent/meshagent/meshagent"

/bin/launchctl load "/Library/LaunchDaemons/meshagent.plist"
